"""
tests/test_roster.py - Automated Unit & Integration Tests for Smart Roster Management System
Tests:
1. Single-resource brand coverage & gap detection
2. Multi-resource brand load sharing and coverage
3. Weekly-off honoring and conflict detection
4. Planned leaves and approved comp-offs
5. Public holidays and operating pattern rules
6. Insufficient staffing detection against min_staff_req
7. Overlapping assignments detection
8. Roster regeneration and change management reassignment
"""

import os
import gc
import pytest
import tempfile
from datetime import date
import database
import sample_data
import scheduler
import validator


@pytest.fixture(scope="module")
def test_db():
    """Sets up a temporary SQLite database initialized with realistic sample data."""
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    sample_data.seed_database(db_path=path, force=True)
    yield path
    gc.collect()
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def test_database_initialization(test_db):
    """Verifies that the database initializes with the required entities."""
    summary = database.get_system_summary(test_db)
    assert summary["total_employees"] >= 30, "Should have at least 30 employees"
    assert summary["total_brands"] == 10, "Should have 10 brands"
    assert summary["single_resource_brands"] == 8, "Should have 8 single-resource brands (~80%)"
    assert summary["multi_resource_brands"] == 2, "Should have 2 multi-resource brands (~20%)"
    assert summary["total_pods"] == 4, "Should have 4 operational pods"
    assert summary["total_processes"] == 4, "Should have 4 processes"


def test_monthly_roster_generation(test_db):
    """Verifies generation of a 30-day monthly roster for November 2026."""
    res = scheduler.generate_monthly_roster(year=2026, month=11, db_path=test_db)
    assert res["roster_id"] is not None
    assert res["month"] == 11
    assert res["year"] == 2026
    # 32 employees * 30 days = 960 entries
    assert res["total_entries"] == 960


def test_operating_patterns(test_db):
    """Tests 365-day, daily_ex_holidays, and sundays_holidays_off operating calendars."""
    from datetime import date
    holidays = {"2026-11-08"}  # Sunday + Diwali

    # 1. 365_days: Always open
    sunday_holiday = date(2026, 11, 8)
    assert scheduler.is_brand_process_open("365_days", sunday_holiday, holidays) is True

    # 2. daily_ex_holidays: Open on regular Sunday, closed on holiday
    regular_sunday = date(2026, 11, 15)
    assert scheduler.is_brand_process_open("daily_ex_holidays", regular_sunday, holidays) is True
    assert scheduler.is_brand_process_open("daily_ex_holidays", sunday_holiday, holidays) is False

    # 3. sundays_holidays_off: Closed on Sundays and Holidays, open on regular weekday
    weekday = date(2026, 11, 11)  # Wednesday
    assert scheduler.is_brand_process_open("sundays_holidays_off", weekday, holidays) is True
    assert scheduler.is_brand_process_open("sundays_holidays_off", regular_sunday, holidays) is False
    assert scheduler.is_brand_process_open("sundays_holidays_off", sunday_holiday, holidays) is False


def test_single_resource_brand_leave_conflict(test_db):
    """
    Verifies that when a single-resource brand's sole operator is on leave,
    the system honestly flags a CRITICAL missing coverage conflict rather than faking coverage.
    """
    # Rahul Mehta (GlowSkin sole operator) has planned leave on 2026-11-12
    confs = database.get_conflicts_for_roster(1, test_db)
    glowskin_confs = [c for c in confs if c["date"] == "2026-11-12" and c["brand_id"] == 1]
    assert len(glowskin_confs) > 0, "GlowSkin must have a conflict on 2026-11-12 due to sole operator leave"
    assert any(c["severity"] == "CRITICAL" for c in glowskin_confs)
    assert any(c["conflict_type"] == "MISSING_COVERAGE" for c in glowskin_confs)


def test_backup_recommendations_and_reassignment(test_db):
    """
    Verifies backup recommendations engine and re-assignment conflict resolution.
    """
    # Get backup candidates for GlowSkin on 2026-11-12
    recs = validator.get_backup_recommendations(brand_id=1, process_id=1, date_str="2026-11-12", roster_id=1, db_path=test_db)
    assert len(recs) > 0, "Should find backup candidates"
    # Highest ranked candidate should be from same pod with process compatibility
    top_cand = recs[0]
    assert top_cand["pod_name"] == "Pod Alpha (North)"
    assert top_cand["score"] >= 80

    # Apply backup reassignment
    updated_confs = validator.resolve_conflict_reassign(
        roster_id=1,
        date_str="2026-11-12",
        brand_id=1,
        process_id=1,
        backup_employee_id=top_cand["employee_id"],
        db_path=test_db
    )
    # GlowSkin conflict should now be resolved
    remaining_glowskin = [c for c in updated_confs["list"] if c["date"] == "2026-11-12" and c["brand_id"] == 1]
    assert len(remaining_glowskin) == 0, "GlowSkin conflict should be resolved after backup allocation"


def test_weekly_off_honoring(test_db):
    """Verifies that employee weekly offs are respected in generated roster."""
    entries = database.get_roster_entries(1, test_db)
    # Check Rahul Mehta (weekly off Sat/Sun)
    rahul_entries = [e for e in entries if e["employee_name"] == "Rahul Mehta"]
    for e in rahul_entries:
        dt = date.fromisoformat(e["date"])
        if dt.strftime("%A") in ["Saturday", "Sunday"] and e["date"] != "2026-11-12":
            assert e["status"] in ["WEEKLY OFF", "HOLIDAY", "LEAVE"], f"Rahul should not be WORKING on {dt.strftime('%A')}"


def test_public_holiday_handling(test_db):
    """Verifies that public holidays assign HOLIDAY or holiday duty appropriately."""
    entries = database.get_roster_entries(1, test_db)
    # Guru Nanak Jayanti is 2026-11-24 (Tuesday)
    nov_24_entries = [e for e in entries if e["date"] == "2026-11-24"]
    assert len(nov_24_entries) > 0
    # Employees on sundays_holidays_off or daily_ex_holidays brands should have HOLIDAY
    holiday_statuses = [e["status"] for e in nov_24_entries]
    assert "HOLIDAY" in holiday_statuses
